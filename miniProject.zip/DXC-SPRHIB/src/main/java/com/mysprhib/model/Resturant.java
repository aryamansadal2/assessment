package com.mysprhib.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Resturant {

	      public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
		@Id
	      String name;
	      String location;
	      String rating;
	      String service;
		public String getService() {
			return service;
		}
		public void setService(String service) {
			this.service = service;
		}
	
	
	
}
