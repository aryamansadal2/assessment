package com.mysprhib.resturantdao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mysprhib.model.Resturant;

@Component
public class ResturantDao {
                  @Autowired
	              SessionFactory sessionFactory;
	
                  @Transactional
                  public void saveResturant(Resturant resturant) {
                	  
                	  
                	      Session session = sessionFactory.getCurrentSession();
                	      session.save(resturant);
                	  
                	  
                	  
                  }
                  
                  @Transactional
                  public Resturant getData(String name)
                  {
                	  Session session = sessionFactory.getCurrentSession();
                	  Resturant resturant=(Resturant)session.get(Resturant.class, name);
                	  return resturant;
                  }
                  
                  @Transactional
                  public ArrayList<Resturant> viewData(Resturant resturant)
                  {
                	  Session session = sessionFactory.getCurrentSession();
                	  ArrayList<Resturant> resturants = (ArrayList<Resturant>)session.createQuery("from Resturant").list();
                	  return resturants;
                  }
                  
                  
                  @Transactional
                  public void updateData(Resturant resturant)
                  
                  {
                	  Session session = sessionFactory.getCurrentSession();
                	  session.update(resturant);
                  }
                 
                  
                  @Transactional
                  public void deleteData(String name)
       	       {
       	    	   
       	    	   Session session = sessionFactory.getCurrentSession();
       	    	   Resturant resturant=(Resturant) session.get(Resturant.class,name);
       	    	   session.delete(resturant);
       	    	         	    	  
       	       }
       	       
                  
	
                  
               
	
	       
}
