package com.mysprhib.demos;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

//import com.mydemos.bean.ShowRoom;
//import com.mydemos.bean.ShowRoom;
import com.mysprhib.model.Resturant;
import com.mysprhib.resturantdao.ResturantDao;


@Controller
public class HomeController {
	ArrayList<Resturant> lis = new ArrayList<Resturant>();
	
	
	
	@RequestMapping(value = "/")
		        
		       public String home(Locale locale,Model model) {	
			   return "home";
	}
	  @Autowired
	  ResturantDao resturantDao;
	
	
	@RequestMapping(value = "/saveResturant")
    
			    public String saveresturant(@ModelAttribute Resturant res) {
		
		        resturantDao.saveResturant(res);
		        lis.add(res);
				return "display";
}
	
	@RequestMapping(value = "/backHome")
    
    public String backHome(@ModelAttribute Resturant res) {

	return "home";
}
	
	@RequestMapping(value = "/dispData")
    
    public String dispData(Model model,@RequestParam("name") String name) {
		Resturant resturant=resturantDao.getData(name);
		model.addAttribute("resturant",resturant);

	return "display";
}
	
	@RequestMapping(value = "/viewData")
	public String viewData(Model model,@ModelAttribute Resturant res)
	{
	  
		ArrayList<Resturant> resturants = resturantDao.viewData(res);
		
		model.addAttribute("resturants",resturants);
		return "displayAll";

	}
	@RequestMapping(value = "/updateData")
	public String updateData(@ModelAttribute Resturant res)
	{
	  
		
	resturantDao.updateData(res);
	return "home";
	

	}
	
	
	
	
	@RequestMapping(value = "/deleteData")
    
    public String deleteData(Model model,@RequestParam("name") String name) {

    
   resturantDao.deleteData(name);
	return "home";
}
	  
	 	
		
		
	
}
