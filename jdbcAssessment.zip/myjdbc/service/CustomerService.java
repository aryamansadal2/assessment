package com.myjdbc.service;

import com.myjdbc.dao.CustomerDao;
import com.myjdbc.pojos.Customer;

public class CustomerService {

public static void main(String[] args) {

//CustomerDao dao=new CustomerDao();


Customer customer = new Customer();

//customer.setCustId("1001");
customer.setCustFname("Aryaman");
customer.setCustLname("Sadal");
customer.setAddress("Jammu");


CustomerDao.saveCustomer(customer);





}

}