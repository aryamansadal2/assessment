package com.myjdbc.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.util.ArrayList;
//import java.util.List;
import java.sql.ResultSet;

import com.myjdbc.dbutil.DbConn;
import com.myjdbc.pojos.Customer;

public class CustomerDao {
	
	public static String saveCustomer(Customer customer) {
		
		String id = "";
			try {
			
			Connection con=DbConn.getConnection();
			String sql="insert into customer values(?,?,?,?)";
			String sql1 = "select idseq.nextval from dual";
			
			PreparedStatement stat=con.prepareStatement(sql);
			PreparedStatement stat1=con.prepareStatement(sql1);
			ResultSet rs = stat1.executeQuery();
			
			
			if(rs.next())
			{
				
				if(rs.getInt(1)<10)
				{
					id=genId(customer)+"00"+rs.getInt(1);
				}
				
				else if(rs.getInt(1)>10)
				{
				id=genId(customer)+"0"+rs.getInt(1);
				System.out.println(rs.getInt(1));
				}
			}
			
			
			customer.setCustId(id);
			
			
			//String id;
			stat.setString(1, customer.getCustId());
			stat.setString(2, customer.getCustFname());
			stat.setString(3, customer.getCustLname());
			stat.setString(4, customer.getAddress());

			int res= stat.executeUpdate();
			if(res>0)
			return "Customer saved";
			
			
			}
			
			catch(Exception e){
				e.printStackTrace();
			}
			
			return "Cannot save Customer";
		
		    
		
		
		
		
		
	}
	
	//--------------------------Generate ID Function---------------------------------------------
	
	public static String genId(Customer customer) {
		String idgen="";
		idgen=customer.getCustFname().substring(0,2)+customer.getCustLname().substring(0,2);
		System.out.println("Test Output : " + idgen);
		return idgen;
	}
	
	
	

}
