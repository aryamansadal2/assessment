package com.myjdbc.pojos;

public class Customer {
	
	
	String custId;
	String custFname;
	String custLname;
	String address;
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getCustFname() {
		return custFname;
	}
	public void setCustFname(String custFname) {
		this.custFname = custFname;
	}
	public String getCustLname() {
		return custLname;
	}
	public void setCustLname(String custLname) {
		this.custLname = custLname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public Customer(String custId, String custFname, String custLname, String address) {
		//super();
		this.custId = custId;
		this.custFname = custFname;
		this.custLname = custLname;
		this.address = address;
	}
	
	
	public Customer() {
		
	}
	
	
	
	@Override
	public String toString() {

	return getCustId()+" "+getCustFname()+" "+getCustLname()+" "+getAddress();

	}
	
	
	

}
