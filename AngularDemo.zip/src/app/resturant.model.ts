

export interface Resturant{



    resturantName:String;
    resturantId:number;
    location:String;
    rating:number;

}