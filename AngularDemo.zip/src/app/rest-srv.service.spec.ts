import { TestBed } from '@angular/core/testing';

import { RestSrvService } from './rest-srv.service';

describe('RestSrvService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RestSrvService = TestBed.get(RestSrvService);
    expect(service).toBeTruthy();
  });
});
