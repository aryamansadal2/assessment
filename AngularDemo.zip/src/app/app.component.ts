import { Component } from '@angular/core';
import { RestSrvService } from './rest-srv.service';
import { Resturant } from './resturant.model';
import { ConstantPool } from '@angular/compiler';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 constructor( private restSrv:RestSrvService){}

 resturant:Resturant = {"resturantId":0,"resturantName":"","location":"","rating":0}



 saveResturant()
 {
     
     this.restSrv.saveResturant(this.resturant).subscribe(

               data=>console.log(data),
               error=>console.log(error)
               
                      
     );

 }


 updateResturant()
 {

  this.restSrv.updateResturant(this.resturant).subscribe(
    data=>console.log(data),
    error=>console.log(error)
  );
 }


 getResturant()
 {

      this.restSrv.getResturant(this.resturant.resturantId).subscribe(
             data=>console.log(data),
             error=>console.log(error)


      );

 }


 deleteResturant()
  {

    //this.resturant.resturantId=1;
    this.restSrv.deleteResturant(this.resturant.resturantId).subscribe(
      data=> console.log(data),
      error=>console.log(error)
    );
  }


  
resturants:Resturant[]=[];
 getAllResturants()
 {

  this.restSrv.getAllResturants().subscribe(


    data=>this.resturants=data,
    error=>console.log(error)

  );

  for(let rest of this.resturants)
  {
    console.log(rest.resturantName);
  }

 }







}
