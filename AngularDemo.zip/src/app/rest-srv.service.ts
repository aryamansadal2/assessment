import { Injectable } from '@angular/core';
import { Resturant } from './resturant.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RestSrvService {

  constructor(private http:HttpClient) { }

  saveResturant(resturant:Resturant)
  {
    return this.http.post<any>('http://localhost:1692/resturant',resturant);
  }

updateResturant(resturant:Resturant)
{
  return this.http.put<Resturant>('http://localhost:1692/resturant',resturant);

}
deleteResturant(resturantId:number)
{
  
   return this.http.delete(`http://localhost:1692/resturant/${resturantId}`);

}

getAllResturants()
{

   return this.http.get<Resturant[]>('http://localhost:1692/resturant')

}

getResturant(resturantId:number)
{

   return this.http.get<Resturant>(`http://localhost:1692/resturant${resturantId}`);

}



}